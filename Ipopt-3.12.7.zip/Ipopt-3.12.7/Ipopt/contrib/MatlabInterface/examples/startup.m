addpath /usr/local/lib
